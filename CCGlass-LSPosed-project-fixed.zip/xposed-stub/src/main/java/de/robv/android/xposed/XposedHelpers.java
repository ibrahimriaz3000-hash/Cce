package de.robv.android.xposed;

public final class XposedHelpers {
    private XposedHelpers() {}
    public static Class<?> findClassIfExists(String className, ClassLoader cl) { return null; }
    public static Object findAndHookMethod(Class<?> clazz, String methodName, Object... parameterTypesAndCallback) { return null; }
    public static Object getAdditionalInstanceField(Object obj, String key) { return null; }
    public static Object setAdditionalInstanceField(Object obj, String key, Object value) { return null; }
}
