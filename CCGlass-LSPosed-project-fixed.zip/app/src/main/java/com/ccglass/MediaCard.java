package com.ccglass;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

import de.robv.android.xposed.XposedBridge;

/** iOS 26 style media card: album art, output button, title, prev / play-pause / next. */
final class MediaCard extends View {
    private static final int Z_NONE = 0, Z_PREV = 1, Z_PLAY = 2, Z_NEXT = 3, Z_OUT = 4;

    private final MediaSessionManager msm;
    private final Handler main = new Handler(Looper.getMainLooper());
    private MediaController mc;
    private String title, artist;
    private Bitmap art;
    private Drawable appIcon;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint soft = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path tmp = new Path();
    private final RectF rf = new RectF();
    private Glass glass;
    private int pressedZone = Z_NONE;

    private final MediaSessionManager.OnActiveSessionsChangedListener sessions =
            new MediaSessionManager.OnActiveSessionsChangedListener() {
                @Override public void onActiveSessionsChanged(List<MediaController> list) { pick(list); }
            };

    private final MediaController.Callback callback = new MediaController.Callback() {
        @Override public void onPlaybackStateChanged(PlaybackState state) { invalidate(); }
        @Override public void onMetadataChanged(MediaMetadata md) { loadMeta(); invalidate(); }
        @Override public void onSessionDestroyed() { refreshSessions(); }
    };

    MediaCard(Context c) {
        super(c);
        msm = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
        ink.setStyle(Paint.Style.FILL_AND_STROKE);
        ink.setStrokeJoin(Paint.Join.ROUND);
        soft.setStyle(Paint.Style.FILL_AND_STROKE);
        soft.setStrokeJoin(Paint.Join.ROUND);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(0xFFFFFFFF);
        text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        text.setColor(0xFFFFFFFF);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        try {
            msm.addOnActiveSessionsChangedListener(sessions, null, main);
        } catch (Throwable t) {
            XposedBridge.log("[CCGlass] media listener: " + t);
        }
        refreshSessions();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        try { msm.removeOnActiveSessionsChangedListener(sessions); } catch (Throwable ignored) {}
        if (mc != null) { try { mc.unregisterCallback(callback); } catch (Throwable ignored) {} mc = null; }
    }

    private void refreshSessions() {
        try { pick(msm.getActiveSessions(null)); }
        catch (Throwable t) { XposedBridge.log("[CCGlass] getActiveSessions: " + t); }
    }

    private void pick(List<MediaController> list) {
        MediaController best = null;
        if (list != null) {
            for (MediaController m : list) {
                PlaybackState s = m.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) { best = m; break; }
                if (best == null) best = m;
            }
        }
        if (best != mc) {
            if (mc != null) { try { mc.unregisterCallback(callback); } catch (Throwable ignored) {} }
            mc = best;
            if (mc != null) { try { mc.registerCallback(callback, main); } catch (Throwable ignored) {} }
            loadMeta();
        }
        invalidate();
    }

    private void loadMeta() {
        title = null; artist = null; art = null; appIcon = null;
        if (mc == null) return;
        try {
            MediaMetadata md = mc.getMetadata();
            if (md != null) {
                title = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                if (title == null) title = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE);
                artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                if (artist == null) artist = md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
                if (artist == null) artist = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE);
                art = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (art == null) art = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
            }
            if (art == null) {
                appIcon = getContext().getPackageManager().getApplicationIcon(mc.getPackageName());
            }
        } catch (PackageManager.NameNotFoundException ignored) {
        } catch (Throwable t) {
            XposedBridge.log("[CCGlass] loadMeta: " + t);
        }
    }

    private boolean playing() {
        if (mc == null) return false;
        PlaybackState s = mc.getPlaybackState();
        return s != null && s.getState() == PlaybackState.STATE_PLAYING;
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        glass = new Glass(w, h, getResources().getDisplayMetrics().density);
    }

    // ---- geometry (reference picture ke ratios, S = card side) ----
    private float S() { return Math.min(getWidth(), getHeight()); }
    private float cxPrev() { return S() * 0.216f; }
    private float cxPlay() { return S() * 0.51f; }
    private float cxNext() { return S() * 0.78f; }
    private float cyCtl() { return S() * 0.837f; }
    private float outR() { return S() * 0.1325f; }
    private float outCx() { return S() - S() * 0.088f - outR(); }
    private float outCy() { return S() * 0.09f + outR(); }

    @Override protected void onDraw(Canvas c) {
        float s = S();
        if (glass != null) glass.draw(c);

        // album art
        float m = s * 0.088f, a = s * 0.35f, top = s * 0.09f, rad = s * 0.06f;
        rf.set(m, top, m + a, top + a);
        if (art != null) {
            tmp.reset();
            tmp.addRoundRect(rf, rad, rad, Path.Direction.CW);
            c.save();
            c.clipPath(tmp);
            c.drawBitmap(art, null, rf, bmpPaint);
            c.restore();
        } else {
            fill.setColor(0x2EFFFFFF);
            c.drawRoundRect(rf, rad, rad, fill);
            if (appIcon != null) {
                float pad = a * 0.2f;
                appIcon.setBounds((int) (m + pad), (int) (top + pad), (int) (m + a - pad), (int) (top + a - pad));
                appIcon.draw(c);
            }
        }

        // output (AirPlay-style) button
        fill.setColor(pressedZone == Z_OUT ? 0x55FFFFFF : 0x38FFFFFF);
        c.drawCircle(outCx(), outCy(), outR(), fill);
        drawOutputGlyph(c, outCx(), outCy(), outR());

        // title / artist
        float tx = m, maxW = s - 2 * m;
        boolean has = title != null && title.length() > 0;
        text.setColor(0xFFFFFFFF);
        text.setTextSize(s * 0.075f);
        String t = has ? title : "Not Playing";
        CharSequence tt = TextUtils.ellipsize(t, new android.text.TextPaint(text), maxW, TextUtils.TruncateAt.END);
        if (has && artist != null && artist.length() > 0) {
            c.drawText(tt, 0, tt.length(), tx, s * 0.585f, text);
            text.setColor(0xB3FFFFFF);
            text.setTextSize(s * 0.056f);
            CharSequence ar = TextUtils.ellipsize(artist, new android.text.TextPaint(text), maxW, TextUtils.TruncateAt.END);
            c.drawText(ar, 0, ar.length(), tx, s * 0.665f, text);
        } else {
            c.drawText(tt, 0, tt.length(), tx, s * 0.62f, text);
        }

        // transport controls
        soft.setColor(pressedZone == Z_PREV ? 0xFFFFFFFF : 0xCCFFFFFF);
        soft.setStrokeWidth(s * 0.02f);
        skip(c, cxPrev(), cyCtl(), s * 0.15f, s * 0.12f, false, soft);
        soft.setColor(pressedZone == Z_NEXT ? 0xFFFFFFFF : 0xCCFFFFFF);
        skip(c, cxNext(), cyCtl(), s * 0.15f, s * 0.12f, true, soft);

        ink.setColor(0xFFFFFFFF);
        ink.setStrokeWidth(s * 0.025f);
        float pr = pressedZone == Z_PLAY ? 0.92f : 1f;
        if (playing()) {
            float bw = s * 0.045f, bh = s * 0.15f * pr, gap = s * 0.04f;
            rf.set(cxPlay() - gap / 2 - bw, cyCtl() - bh / 2, cxPlay() - gap / 2, cyCtl() + bh / 2);
            c.drawRoundRect(rf, bw * 0.3f, bw * 0.3f, ink);
            rf.set(cxPlay() + gap / 2, cyCtl() - bh / 2, cxPlay() + gap / 2 + bw, cyCtl() + bh / 2);
            c.drawRoundRect(rf, bw * 0.3f, bw * 0.3f, ink);
        } else {
            float pw = s * 0.135f * pr, ph = s * 0.16f * pr;
            tmp.reset();
            float x0 = cxPlay() - pw * 0.4f;
            tmp.moveTo(x0, cyCtl() - ph / 2);
            tmp.lineTo(x0 + pw, cyCtl());
            tmp.lineTo(x0, cyCtl() + ph / 2);
            tmp.close();
            c.drawPath(tmp, ink);
        }
    }

    private void skip(Canvas c, float cx, float cy, float w, float h, boolean fwd, Paint p) {
        float hw = w / 2f;
        for (int i = 0; i < 2; i++) {
            float x0 = cx - w / 2f + i * hw;
            tmp.reset();
            if (fwd) {
                tmp.moveTo(x0, cy - h / 2); tmp.lineTo(x0 + hw, cy); tmp.lineTo(x0, cy + h / 2);
            } else {
                tmp.moveTo(x0 + hw, cy - h / 2); tmp.lineTo(x0, cy); tmp.lineTo(x0 + hw, cy + h / 2);
            }
            tmp.close();
            c.drawPath(tmp, p);
        }
    }

    private void drawOutputGlyph(Canvas c, float cx, float cy, float r) {
        float u = r * 0.5f;
        line.setStrokeWidth(u * 0.2f);
        line.setColor(0xFFFFFFFF);
        float[] radii = {0.55f, 1.0f};
        for (float rr : radii) {
            rf.set(cx - u * rr, cy - u * rr - u * 0.1f, cx + u * rr, cy + u * rr - u * 0.1f);
            c.drawArc(rf, 140, 260, false, line);
        }
        fill.setColor(0xFFFFFFFF);
        c.drawCircle(cx, cy - u * 0.1f, u * 0.17f, fill);
        tmp.reset();
        tmp.moveTo(cx - u * 0.7f, cy + u * 0.95f);
        tmp.lineTo(cx, cy + u * 0.15f);
        tmp.lineTo(cx + u * 0.7f, cy + u * 0.95f);
        tmp.close();
        c.drawPath(tmp, fill);
    }

    private int zoneAt(float x, float y) {
        float s = S();
        float rr = s * 0.13f;
        if (dist(x, y, outCx(), outCy()) <= outR() * 1.1f) return Z_OUT;
        if (dist(x, y, cxPrev(), cyCtl()) <= rr) return Z_PREV;
        if (dist(x, y, cxPlay(), cyCtl()) <= rr) return Z_PLAY;
        if (dist(x, y, cxNext(), cyCtl()) <= rr) return Z_NEXT;
        return Z_NONE;
    }

    private static float dist(float x1, float y1, float x2, float y2) {
        float dx = x1 - x2, dy = y1 - y2;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                int z = zoneAt(e.getX(), e.getY());
                if (z == Z_NONE) return false;
                pressedZone = z;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (pressedZone != Z_NONE && zoneAt(e.getX(), e.getY()) != pressedZone) {
                    pressedZone = Z_NONE;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP: {
                int z = pressedZone;
                pressedZone = Z_NONE;
                invalidate();
                if (z != Z_NONE) act(z);
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                pressedZone = Z_NONE;
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }

    private void act(int z) {
        try {
            switch (z) {
                case Z_PREV:
                    if (mc != null) mc.getTransportControls().skipToPrevious(); else key(KeyEvent.KEYCODE_MEDIA_PREVIOUS);
                    break;
                case Z_NEXT:
                    if (mc != null) mc.getTransportControls().skipToNext(); else key(KeyEvent.KEYCODE_MEDIA_NEXT);
                    break;
                case Z_PLAY:
                    if (mc != null) {
                        if (playing()) mc.getTransportControls().pause(); else mc.getTransportControls().play();
                    } else key(KeyEvent.KEYCODE_MEDIA_PLAY);
                    break;
                case Z_OUT:
                    openOutput();
                    break;
            }
        } catch (Throwable t) {
            XposedBridge.log("[CCGlass] media action: " + t);
        }
    }

    private void key(int code) {
        AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    private void openOutput() {
        Context c = getContext();
        try {
            Intent i = new Intent("com.android.systemui.action.LAUNCH_MEDIA_OUTPUT_DIALOG");
            i.setPackage("com.android.systemui");
            if (mc != null) i.putExtra("package_name", mc.getPackageName());
            c.sendBroadcast(i);
        } catch (Throwable t) {
            try {
                c.startActivity(new Intent(Settings.Panel.ACTION_VOLUME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Throwable t2) {
                XposedBridge.log("[CCGlass] output: " + t2);
            }
        }
    }
}
