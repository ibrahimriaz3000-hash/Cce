package com.ccglass;

import android.content.Context;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import de.robv.android.xposed.XposedBridge;

/**
 * Control Center root par do glass cards inject karta hai:
 *  - media tile ("No playback history") ki jagah: MediaCard
 *  - uske neeche wale 2x2 toggle block ki jagah: ConnectivityCard
 * Original views ko INVISIBLE rakhta hai aur har frame cards ko tile ki position/alpha ke saath sync karta hai.
 */
final class Controller implements ViewTreeObserver.OnPreDrawListener, ViewTreeObserver.OnGlobalLayoutListener {
    private static final String TAG = "[CCGlass] ";
    private static final Pattern PLAYBACK = Pattern.compile("(?i)(no playback|not playing|playback hist)");

    private final FrameLayout root;
    private final Context ctx;
    private ConnectivityCard conn;
    private MediaCard media;
    private View tile;
    private final List<View> hidden = new ArrayList<>();
    private final int[] a = new int[2];
    private final int[] b = new int[2];
    private long lastFind, lastRebuild;
    private boolean dumpedAttach, dumpedTile;

    Controller(FrameLayout root) {
        this.root = root;
        this.ctx = root.getContext();
    }

    void onAttached() {
        ViewTreeObserver vto = root.getViewTreeObserver();
        if (vto.isAlive()) {
            vto.removeOnPreDrawListener(this);
            vto.removeOnGlobalLayoutListener(this);
            vto.addOnPreDrawListener(this);
            vto.addOnGlobalLayoutListener(this);
        }
        ensureViews();
        if (!dumpedAttach) {
            dumpedAttach = true;
            root.postDelayed(new Runnable() {
                @Override public void run() { dump("attach+2s"); }
            }, 2000);
        }
    }

    private void ensureViews() {
        if (conn == null) {
            conn = new ConnectivityCard(ctx);
            media = new MediaCard(ctx);
            conn.setVisibility(View.INVISIBLE);
            media.setVisibility(View.INVISIBLE);
        }
        if (conn.getParent() != root) {
            if (conn.getParent() instanceof ViewGroup) ((ViewGroup) conn.getParent()).removeView(conn);
            root.addView(conn, lp());
        }
        if (media.getParent() != root) {
            if (media.getParent() instanceof ViewGroup) ((ViewGroup) media.getParent()).removeView(media);
            root.addView(media, lp());
        }
    }

    private FrameLayout.LayoutParams lp() {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(U.dp(ctx, 150), U.dp(ctx, 150));
        p.gravity = Gravity.TOP | Gravity.START;
        return p;
    }

    // ---------------------------------------------------------------- per-frame sync

    @Override public boolean onPreDraw() {
        try {
            if (tile == null || !tile.isAttachedToWindow()) {
                long now = SystemClock.uptimeMillis();
                if (now - lastFind > 500 && root.getWidth() > 0) {
                    lastFind = now;
                    tile = findTile();
                    if (tile != null) {
                        XposedBridge.log(TAG + "media tile = " + tile.getClass().getName()
                                + " id=" + U.idName(tile) + " " + tile.getWidth() + "x" + tile.getHeight());
                        rebuildHidden();
                        if (!dumpedTile) { dumpedTile = true; dump("tile found"); }
                    }
                }
            }
            if (tile == null) {
                if (conn != null) { conn.setVisibility(View.INVISIBLE); media.setVisibility(View.INVISIBLE); }
                return true;
            }
            sync();
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
        return true;
    }

    @Override public void onGlobalLayout() {
        if (tile == null) return;
        long now = SystemClock.uptimeMillis();
        if (now - lastRebuild < 300) return;
        lastRebuild = now;
        try { rebuildHidden(); } catch (Throwable t) { XposedBridge.log(t); }
    }

    private void sync() {
        int w = tile.getWidth(), h = tile.getHeight();
        if (w <= 0 || h <= 0) return;
        tile.getLocationInWindow(a);
        root.getLocationInWindow(b);
        int x = a[0] - b[0], y = a[1] - b[1];
        int gap = Math.round(h * 0.10f);

        setSize(media, w, h);
        setSize(conn, w, h);
        media.setTranslationX(x);
        media.setTranslationY(y);
        conn.setTranslationX(x);
        conn.setTranslationY(y + h + gap);

        float alpha = 1f;
        boolean visible = true;
        View v = tile;
        while (v != null && v != root) {
            alpha *= v.getAlpha();
            if (v != tile && v.getVisibility() != View.VISIBLE) visible = false;
            ViewParent p = v.getParent();
            v = (p instanceof View) ? (View) p : null;
        }
        int vis = visible ? View.VISIBLE : View.INVISIBLE;
        media.setAlpha(alpha);
        conn.setAlpha(alpha);
        if (media.getVisibility() != vis) media.setVisibility(vis);
        if (conn.getVisibility() != vis) conn.setVisibility(vis);

        for (int i = 0; i < hidden.size(); i++) {
            View hv = hidden.get(i);
            if (hv.getVisibility() == View.VISIBLE) hv.setVisibility(View.INVISIBLE);
        }
    }

    private static void setSize(View v, int w, int h) {
        ViewGroup.LayoutParams p = v.getLayoutParams();
        if (p.width != w || p.height != h) {
            p.width = w;
            p.height = h;
            v.setLayoutParams(p);
        }
    }

    // ---------------------------------------------------------------- finding views

    private View findTile() {
        final View[] hit = new View[1];
        final String[] why = new String[1];
        findText(root, hit);
        View start = hit[0];
        if (start == null) start = findByIdName(root);
        if (start == null) return null;

        int rw = root.getWidth();
        View best = null;
        View cur = start;
        while (cur != null && cur != root) {
            int w = cur.getWidth(), h = cur.getHeight();
            if (w > rw * 0.6f) break;
            if (w >= rw * 0.25f && h >= w * 0.5f) best = cur;
            ViewParent p = cur.getParent();
            cur = (p instanceof View) ? (View) p : null;
        }
        return best;
    }

    private void findText(View v, View[] out) {
        if (out[0] != null || v == conn || v == media) return;
        if (v instanceof TextView) {
            CharSequence t = ((TextView) v).getText();
            if (t != null && PLAYBACK.matcher(t).find()) { out[0] = v; return; }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) findText(g.getChildAt(i), out);
        }
    }

    private View findByIdName(View v) {
        if (v == conn || v == media) return null;
        String n = U.idName(v).toLowerCase();
        int rw = root.getWidth();
        if ((n.contains("media") || n.contains("miplay")) && v.getWidth() >= rw * 0.25f && v.getWidth() <= rw * 0.6f) {
            return v;
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = findByIdName(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    /** Tile + uske neeche wale square slot ke andar poori tarah aane wale original views ko hide list mein daalo. */
    private void rebuildHidden() {
        hidden.clear();
        hidden.add(tile);
        tile.getLocationInWindow(a);
        int w = tile.getWidth(), h = tile.getHeight();
        int gap = Math.round(h * 0.10f);
        Rect slot = new Rect(a[0], a[1] + h + gap, a[0] + w, a[1] + h + gap + h);
        collect(root, slot, U.dp(ctx, 10));
        // conn card ka size/position bhi isi slot se milta hai
    }

    private void collect(ViewGroup g, Rect slot, int tol) {
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            if (c == conn || c == media || c == tile) continue;
            if (c.getVisibility() == View.GONE) continue;
            int cw = c.getWidth(), ch = c.getHeight();
            if (cw <= 0 || ch <= 0) continue;
            c.getLocationInWindow(b);
            Rect r = new Rect(b[0], b[1], b[0] + cw, b[1] + ch);
            boolean contained = r.left >= slot.left - tol && r.top >= slot.top - tol
                    && r.right <= slot.right + tol && r.bottom <= slot.bottom + tol;
            if (contained) {
                hidden.add(c);
            } else if (c instanceof ViewGroup && Rect.intersects(r, slot)) {
                collect((ViewGroup) c, slot, tol);
            }
        }
    }

    // ---------------------------------------------------------------- debug dump

    private void dump(String why) {
        try {
            StringBuilder sb = new StringBuilder("# CCGlass dump: ").append(why)
                    .append("\n# root=").append(root.getClass().getName())
                    .append(" ").append(root.getWidth()).append("x").append(root.getHeight()).append("\n");
            dumpView(root, 0, sb);
            File dir;
            try { dir = ctx.getApplicationContext().getFilesDir(); } catch (Throwable t) { dir = ctx.getFilesDir(); }
            File f = new File(dir, "cc_dump.txt");
            FileWriter fw = new FileWriter(f, false);
            fw.write(sb.toString());
            fw.close();
            XposedBridge.log(TAG + "dump written: " + f.getAbsolutePath() + " (" + sb.length() + " chars)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "dump failed: " + t);
        }
    }

    private void dumpView(View v, int depth, StringBuilder sb) {
        if (sb.length() > 400000) return;
        for (int i = 0; i < depth; i++) sb.append("  ");
        int[] l = new int[2];
        v.getLocationInWindow(l);
        sb.append(v.getClass().getName())
                .append(" id=").append(U.idName(v))
                .append(" [").append(l[0]).append(",").append(l[1]).append(",")
                .append(l[0] + v.getWidth()).append(",").append(l[1] + v.getHeight()).append("]")
                .append(" a=").append(v.getAlpha())
                .append(" vis=").append(v.getVisibility());
        if (v.isClickable()) sb.append(" click");
        if (v instanceof TextView) sb.append(" text=\"").append(((TextView) v).getText()).append("\"");
        if (v.getContentDescription() != null) sb.append(" desc=\"").append(v.getContentDescription()).append("\"");
        sb.append("\n");
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) dumpView(g.getChildAt(i), depth + 1, sb);
        }
    }
}
