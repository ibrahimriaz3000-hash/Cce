package com.ccglass;

import android.content.Context;
import android.view.View;

final class U {
    private U() {}

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static String idName(View v) {
        try {
            int id = v.getId();
            if (id == View.NO_ID) return "";
            return v.getResources().getResourceEntryName(id);
        } catch (Throwable t) {
            return "";
        }
    }
}
