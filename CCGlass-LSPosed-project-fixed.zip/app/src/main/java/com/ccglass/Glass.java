package com.ccglass;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;

/** Liquid-glass card background: translucent fill + gradient border. */
final class Glass {
    private final RectF rect;
    private final float radius;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);

    Glass(int w, int h, float density) {
        float s = Math.min(w, h);
        radius = s * 0.20f;
        rect = new RectF(density, density, w - density, h - density);
        fill.setShader(new LinearGradient(0, 0, 0, h, 0x52FFFFFF, 0x2EFFFFFF, Shader.TileMode.CLAMP));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.3f * density);
        stroke.setShader(new LinearGradient(0, 0, w, h, 0xB0FFFFFF, 0x26FFFFFF, Shader.TileMode.CLAMP));
    }

    void draw(Canvas c) {
        c.drawRoundRect(rect, radius, radius, fill);
        c.drawRoundRect(rect, radius, radius, stroke);
    }
}
