package com.ccglass;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Process;
import android.os.UserHandle;
import android.provider.Settings;
import android.telephony.SubscriptionManager;
import android.telephony.TelephonyManager;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.Executor;

import de.robv.android.xposed.XposedBridge;

/** State read + toggle logic. SystemUI ke privileges se chalta hai. */
@SuppressWarnings({"deprecation", "MissingPermission"})
final class Toggles {
    enum Kind { AIRPLANE, HOTSPOT, WIFI, DATA, BLUETOOTH, ROTATION, LOCATION }

    private Toggles() {}

    static boolean read(Context c, Kind k) {
        try {
            switch (k) {
                case AIRPLANE:
                    return Settings.Global.getInt(c.getContentResolver(),
                            Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
                case WIFI: {
                    WifiManager w = (WifiManager) c.getSystemService(Context.WIFI_SERVICE);
                    return w != null && w.isWifiEnabled();
                }
                case HOTSPOT: {
                    WifiManager w = (WifiManager) c.getSystemService(Context.WIFI_SERVICE);
                    Object r = w.getClass().getMethod("isWifiApEnabled").invoke(w);
                    return Boolean.TRUE.equals(r);
                }
                case DATA: {
                    TelephonyManager t = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
                    return t != null && t.isDataEnabled();
                }
                case BLUETOOTH: {
                    BluetoothManager bm = (BluetoothManager) c.getSystemService(Context.BLUETOOTH_SERVICE);
                    BluetoothAdapter a = bm != null ? bm.getAdapter() : null;
                    return a != null && a.isEnabled();
                }
                case ROTATION:
                    // "on" = rotation locked
                    return Settings.System.getInt(c.getContentResolver(),
                            Settings.System.ACCELEROMETER_ROTATION, 1) == 0;
                case LOCATION: {
                    LocationManager l = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
                    return l != null && l.isLocationEnabled();
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    static void toggle(final Context c, final Kind k, final boolean currentlyOn) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    doToggle(c, k, currentlyOn);
                } catch (Throwable t) {
                    XposedBridge.log("[CCGlass] toggle " + k + " failed: " + t);
                    openSettings(c, k);
                }
            }
        }, "ccglass-toggle").start();
    }

    private static void doToggle(Context c, Kind k, boolean on) throws Throwable {
        switch (k) {
            case AIRPLANE: {
                ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
                cm.getClass().getMethod("setAirplaneMode", boolean.class).invoke(cm, !on);
                break;
            }
            case WIFI: {
                WifiManager w = (WifiManager) c.getSystemService(Context.WIFI_SERVICE);
                w.setWifiEnabled(!on);
                break;
            }
            case DATA: {
                TelephonyManager t = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
                int sub = SubscriptionManager.getDefaultDataSubscriptionId();
                TelephonyManager tt = SubscriptionManager.isValidSubscriptionId(sub)
                        ? t.createForSubscriptionId(sub) : t;
                tt.setDataEnabled(!on);
                break;
            }
            case BLUETOOTH: {
                BluetoothManager bm = (BluetoothManager) c.getSystemService(Context.BLUETOOTH_SERVICE);
                BluetoothAdapter a = bm.getAdapter();
                if (on) a.disable(); else a.enable();
                break;
            }
            case ROTATION:
                Settings.System.putInt(c.getContentResolver(),
                        Settings.System.ACCELEROMETER_ROTATION, on ? 1 : 0);
                break;
            case LOCATION: {
                LocationManager l = (LocationManager) c.getSystemService(Context.LOCATION_SERVICE);
                Method m = l.getClass().getMethod("setLocationEnabledForUser", boolean.class, UserHandle.class);
                m.invoke(l, !on, Process.myUserHandle());
                break;
            }
            case HOTSPOT: {
                Object tm = c.getSystemService("tethering");
                if (on) {
                    tm.getClass().getMethod("stopTethering", int.class).invoke(tm, 0);
                } else {
                    Class<?> cbCls = Class.forName("android.net.TetheringManager$StartTetheringCallback");
                    Object cb = Proxy.newProxyInstance(cbCls.getClassLoader(), new Class<?>[]{cbCls},
                            (proxy, method, args) -> null);
                    Executor direct = Runnable::run;
                    tm.getClass().getMethod("startTethering", int.class, Executor.class, cbCls)
                            .invoke(tm, 0, direct, cb);
                }
                break;
            }
        }
    }

    static void openSettings(Context c, Kind k) {
        String action;
        switch (k) {
            case AIRPLANE: action = Settings.ACTION_AIRPLANE_MODE_SETTINGS; break;
            case WIFI: action = Settings.ACTION_WIFI_SETTINGS; break;
            case BLUETOOTH: action = Settings.ACTION_BLUETOOTH_SETTINGS; break;
            case DATA: action = Settings.ACTION_NETWORK_OPERATOR_SETTINGS; break;
            case LOCATION: action = Settings.ACTION_LOCATION_SOURCE_SETTINGS; break;
            case HOTSPOT: action = "android.settings.TETHER_SETTINGS"; break;
            default: return;
        }
        try {
            Intent i = new Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            XposedBridge.log("[CCGlass] openSettings " + k + ": " + t);
        }
    }
}
