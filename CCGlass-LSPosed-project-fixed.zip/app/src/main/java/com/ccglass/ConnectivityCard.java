package com.ccglass;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

import androidx.core.graphics.PathParser;

import de.robv.android.xposed.XposedBridge;

/** iOS 26 style connectivity card: Airplane, Hotspot, Wi-Fi (big) + Data, Bluetooth, Rotation, Location (small). */
final class ConnectivityCard extends View {
    private static final String AIRPLANE_PATH =
            "M21,16v-2l-8,-5V3.5c0,-0.83 -0.67,-1.5 -1.5,-1.5S10,2.67 10,3.5V9l-8,5v2l8,-2.5V19l-2,1.5V22l3.5,-1 3.5,1v-1.5L13,19v-5.5l8,2.5z";
    private static final String WIFI_PATH =
            "M1,9l2,2c4.97,-4.97 13.03,-4.97 18,0l2,-2C16.93,2.93 7.08,2.93 1,9zM9,17l3,3 3,-3c-1.65,-1.66 -4.34,-1.66 -6,0zM5,13l2,2c2.76,-2.76 7.24,-2.76 10,0l2,-2C15.14,9.14 8.87,9.14 5,13z";
    private static final String BT_PATH =
            "M17.71,7.71L12,2h-1v7.59L6.41,5 5,6.41 10.59,12 5,17.59 6.41,19 11,14.41V22h1l5.71,-5.71 -4.3,-4.29 4.3,-4.29zM13,5.83l1.88,1.88L13,9.59V5.83zM14.88,16.29L13,18.17v-3.76l1.88,1.88z";

    private static final class Btn {
        final Toggles.Kind kind;
        float cx, cy, r;
        boolean on;
        Btn(Toggles.Kind k) { kind = k; }
        boolean hit(float x, float y) {
            float dx = x - cx, dy = y - cy;
            return dx * dx + dy * dy <= (r * 1.08f) * (r * 1.08f);
        }
    }

    private final Btn[] btns = new Btn[]{
            new Btn(Toggles.Kind.AIRPLANE), new Btn(Toggles.Kind.HOTSPOT), new Btn(Toggles.Kind.WIFI),
            new Btn(Toggles.Kind.DATA), new Btn(Toggles.Kind.BLUETOOTH),
            new Btn(Toggles.Kind.ROTATION), new Btn(Toggles.Kind.LOCATION)
    };

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyph = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tmp = new Path();
    private final RectF rf = new RectF();
    private Path airplane, wifi, bluetooth;
    private Glass glass;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Btn pressed;
    private boolean longFired;

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 1000);
        }
    };

    private final Runnable longPress = new Runnable() {
        @Override public void run() {
            if (pressed != null) {
                longFired = true;
                Toggles.openSettings(getContext(), pressed.kind);
                pressed = null;
                invalidate();
            }
        }
    };

    ConnectivityCard(Context c) {
        super(c);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(U.dp(c, 1));
        ring.setColor(0x40FFFFFF);
        glyph.setStyle(Paint.Style.FILL);
        glyph.setColor(0xFFFFFFFF);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setColor(0xFFFFFFFF);
        try {
            airplane = PathParser.createPathFromPathData(AIRPLANE_PATH);
            wifi = PathParser.createPathFromPathData(WIFI_PATH);
            bluetooth = PathParser.createPathFromPathData(BT_PATH);
        } catch (Throwable t) {
            XposedBridge.log("[CCGlass] path parse: " + t);
        }
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        handler.removeCallbacks(poll);
        handler.post(poll);
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        handler.removeCallbacks(poll);
        handler.removeCallbacks(longPress);
    }

    private void refresh() {
        if (getVisibility() != VISIBLE || getAlpha() < 0.05f) return;
        boolean changed = false;
        for (Btn b : btns) {
            boolean s = Toggles.read(getContext(), b.kind);
            if (s != b.on) { b.on = s; changed = true; }
        }
        if (changed) invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        float s = Math.min(w, h);
        float m = s * 0.0875f, big = s * 0.367f, sm = s * 0.165f, gp = s * 0.036f;
        set(btns[0], m + big / 2, m + big / 2, big / 2);            // airplane
        set(btns[1], s - m - big / 2, m + big / 2, big / 2);        // hotspot
        set(btns[2], m + big / 2, s - m - big / 2, big / 2);        // wifi
        float c2 = s - m - sm / 2, c1 = c2 - sm - gp;
        float r2 = s - m - sm / 2, r1 = r2 - sm - gp;
        set(btns[3], c1, r1, sm / 2);                               // data
        set(btns[4], c2, r1, sm / 2);                               // bluetooth
        set(btns[5], c1, r2, sm / 2);                               // rotation lock
        set(btns[6], c2, r2, sm / 2);                               // location
        glass = new Glass(w, h, getResources().getDisplayMetrics().density);
    }

    private static void set(Btn b, float cx, float cy, float r) { b.cx = cx; b.cy = cy; b.r = r; }

    private static int activeColor(Toggles.Kind k) {
        switch (k) {
            case DATA: return 0xFF34C759;
            case AIRPLANE: return 0xFFFF9500;
            case ROTATION: return 0xFFFF3B30;
            default: return 0xFF2F8CFF;
        }
    }

    @Override protected void onDraw(Canvas c) {
        if (glass != null) glass.draw(c);
        for (Btn b : btns) {
            float r = b.r * (b == pressed ? 0.93f : 1f);
            fill.setColor(b.on ? activeColor(b.kind) : 0x40FFFFFF);
            c.drawCircle(b.cx, b.cy, r, fill);
            c.drawCircle(b.cx, b.cy, r, ring);
            glyph.setAlpha(b.on ? 255 : 215);
            line.setAlpha(b.on ? 255 : 215);
            drawGlyph(c, b, r * 1.05f);
        }
    }

    private void drawPath(Canvas c, Path p, float cx, float cy, float s) {
        if (p == null) return;
        c.save();
        c.translate(cx - s / 2, cy - s / 2);
        c.scale(s / 24f, s / 24f);
        c.drawPath(p, glyph);
        c.restore();
    }

    private void drawGlyph(Canvas c, Btn b, float s) {
        float cx = b.cx, cy = b.cy, u = s / 2f;
        switch (b.kind) {
            case AIRPLANE: drawPath(c, airplane, cx, cy, s * 1.15f); break;
            case WIFI: drawPath(c, wifi, cx, cy, s * 1.2f); break;
            case BLUETOOTH: drawPath(c, bluetooth, cx, cy, s * 1.1f); break;
            case HOTSPOT: {
                line.setStrokeWidth(u * 0.17f);
                glyph.setStyle(Paint.Style.FILL);
                c.drawCircle(cx, cy, u * 0.17f, glyph);
                float[] radii = {0.5f, 0.85f, 1.2f};
                for (float rr : radii) {
                    rf.set(cx - u * rr, cy - u * rr, cx + u * rr, cy + u * rr);
                    c.drawArc(rf, 130, 280, false, line);
                }
                break;
            }
            case DATA: {
                float bw = s * 0.19f, gap = s * 0.08f;
                float total = 4 * bw + 3 * gap;
                float x = cx - total / 2, bottom = cy + s * 0.48f;
                float[] hs = {0.3f, 0.52f, 0.76f, 1f};
                for (int i = 0; i < 4; i++) {
                    float hh = s * 0.95f * hs[i];
                    rf.set(x + i * (bw + gap), bottom - hh, x + i * (bw + gap) + bw, bottom);
                    c.drawRoundRect(rf, bw * 0.3f, bw * 0.3f, glyph);
                }
                break;
            }
            case ROTATION: {
                float r = s * 0.46f;
                line.setStrokeWidth(s * 0.11f);
                rf.set(cx - r, cy - r, cx + r, cy + r);
                float start = -50, sweep = 290;
                c.drawArc(rf, start, sweep, false, line);
                double ang = Math.toRadians(start + sweep);
                float px = cx + (float) (r * Math.cos(ang)), py = cy + (float) (r * Math.sin(ang));
                float tx = (float) -Math.sin(ang), ty = (float) Math.cos(ang);
                float nx = (float) Math.cos(ang), ny = (float) Math.sin(ang);
                tmp.reset();
                tmp.moveTo(px + tx * s * 0.30f, py + ty * s * 0.30f);
                tmp.lineTo(px - tx * s * 0.05f + nx * s * 0.22f, py - ty * s * 0.05f + ny * s * 0.22f);
                tmp.lineTo(px - tx * s * 0.05f - nx * s * 0.22f, py - ty * s * 0.05f - ny * s * 0.22f);
                tmp.close();
                c.drawPath(tmp, glyph);
                rf.set(cx - s * 0.14f, cy - s * 0.02f, cx + s * 0.14f, cy + s * 0.20f);
                c.drawRoundRect(rf, s * 0.04f, s * 0.04f, glyph);
                line.setStrokeWidth(s * 0.06f);
                rf.set(cx - s * 0.08f, cy - s * 0.17f, cx + s * 0.08f, cy + s * 0.05f);
                c.drawArc(rf, 180, 180, false, line);
                break;
            }
            case LOCATION: {
                tmp.reset();
                tmp.setFillType(Path.FillType.EVEN_ODD);
                tmp.addCircle(cx, cy - s * 0.10f, s * 0.30f, Path.Direction.CW);
                tmp.moveTo(cx - s * 0.26f, cy + s * 0.02f);
                tmp.lineTo(cx, cy + s * 0.46f);
                tmp.lineTo(cx + s * 0.26f, cy + s * 0.02f);
                tmp.close();
                c.drawPath(tmp, glyph);
                // andar ka chhota hole
                int old = fill.getColor();
                fill.setColor(b.on ? activeColor(b.kind) : 0xFF8E9399);
                c.drawCircle(cx, cy - s * 0.10f, s * 0.11f, fill);
                fill.setColor(old);
                break;
            }
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                Btn hit = null;
                for (Btn b : btns) if (b.hit(e.getX(), e.getY())) { hit = b; break; }
                if (hit == null) return false;
                pressed = hit;
                longFired = false;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                handler.postDelayed(longPress, 450);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (pressed != null && !pressed.hit(e.getX(), e.getY())) {
                    handler.removeCallbacks(longPress);
                    pressed = null;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP: {
                handler.removeCallbacks(longPress);
                Btn b = pressed;
                pressed = null;
                invalidate();
                if (b != null && !longFired) {
                    Toggles.toggle(getContext(), b.kind, b.on);
                    b.on = !b.on;           // optimistic update
                    invalidate();
                    handler.postDelayed(new Runnable() {
                        @Override public void run() { refresh(); }
                    }, 700);
                }
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                handler.removeCallbacks(longPress);
                pressed = null;
                invalidate();
                return true;
        }
        return super.onTouchEvent(e);
    }
}
