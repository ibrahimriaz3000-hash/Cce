package com.ccglass;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    private static final String SYSTEMUI = "com.android.systemui";
    // Host SystemUI mein maujood interface (uploaded MiuiSystemUI.apk mein confirm hua)
    private static final String CC_IFACE =
            "com.android.systemui.plugins.miui.controlcenter.ControlCenterWindowView";
    private static final String FIELD = "ccglass_controller";

    private final Set<String> seen = new HashSet<>();

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!SYSTEMUI.equals(lpparam.packageName)) return;
        final Class<?> iface = XposedHelpers.findClassIfExists(CC_IFACE, lpparam.classLoader);
        XposedBridge.log("[CCGlass] SystemUI loaded, iface=" + iface);
        try {
            XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        View v = (View) param.thisObject;
                        String name = v.getClass().getName();
                        // Diagnostic: control center se related har naya class ek baar log hoga
                        String low = name.toLowerCase();
                        if (low.contains("controlcenter") && seen.add(name)) {
                            XposedBridge.log("[CCGlass] saw view class: " + name);
                        }
                        boolean match = (iface != null && iface.isInstance(v))
                                || name.contains("ControlCenterWindowView");
                        if (!match) return;
                        if (!(v instanceof FrameLayout)) {
                            XposedBridge.log("[CCGlass] CC root is not FrameLayout: " + name
                                    + " (" + (v instanceof ViewGroup) + ")");
                            return;
                        }
                        Controller c = (Controller) XposedHelpers.getAdditionalInstanceField(v, FIELD);
                        if (c == null) {
                            c = new Controller((FrameLayout) v);
                            XposedHelpers.setAdditionalInstanceField(v, FIELD, c);
                            XposedBridge.log("[CCGlass] attached to " + name);
                        }
                        c.onAttached();
                    } catch (Throwable t) {
                        XposedBridge.log(t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }
}
