# CC Glass (LSPosed module)

HyperOS Control Center ko iOS 26 "liquid glass" cards jaisa banata hai:
- Media tile ("No playback history") -> glass Media card (art, output button, prev/play/next)
- Uske neeche wala 2x2 toggle block -> glass Connectivity card
  (Airplane, Hotspot, Wi-Fi bade circles; Data, Bluetooth, Rotation lock, Location chhote circles)

## Build (GitHub)
1. Naya GitHub repo banayein, is zip ka saara content upload/push karein.
2. Actions tab -> "Build CCGlass" -> Run workflow (ya push par khud chalega).
3. Run complete hone par Artifacts se `CCGlass-apk` download karein -> `app-release.apk`.
   (Xposed API ab local stub module `xposed-stub` se aati hai, isliye `api.xposed.info` ki zarurat nahi.)

## Install
1. APK install karein.
2. LSPosed -> Modules -> CC Glass -> enable, scope: **System UI** (com.android.systemui).
3. SystemUI restart: `su -c "killall com.android.systemui"` (ya reboot).
4. Control Center kholein.

## Agar kuch ghalat nazar aaye (debug)
Module pehli dafa Control Center ka poora view tree file mein likhta hai:

    su -c "cat /data/user/0/com.android.systemui/files/cc_dump.txt"

Ye file aur LSPosed log (lines jin mein `[CCGlass]` hai) bhej dein, phir main exact ids/positions set kar dunga.

## Safety
Module sirf SystemUI process mein chalta hai. Bootloop ki surat mein: Magisk/LSPosed se module disable karein
(ya `adb shell su -c "killall com.android.systemui"` ke baad LSPosed mein module off).
